﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowProject;
using WindowProjectLib;

namespace WindowsProject_
{
    public partial class MainForm : Form
    {
        string s_ip;
        int i_port;
        RemoteClient RCF = null; // Remote Control form
        Cursor CS = null;
        public MainForm()
        {
            InitializeComponent();
            SetupServer.Start(NetworkInfomation.DefaultIP, NetworkInfomation.SetupPort);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Rectangle rect = Remote.Single.Rect;
            Bitmap bit = new Bitmap(rect.Width, rect.Height);
            Graphics graphics = Graphics.FromImage(bit);

            Size size_ = new Size(rect.Width, rect.Height);
            graphics.CopyFromScreen(new Point(0, 0), new Point(0, 0), size_);
            graphics.Dispose();

            try
            {
                ImageClient ImageC = new ImageClient();
                ImageC.Connect(s_ip, NetworkInfomation.ImgPort);
                ImageC.SendImageAsync(bit, null);
            }
            catch
            {
                timer1.Stop();
                MessageBox.Show("Error : 서버에 문제가 있습니다.");
                this.Close();
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
        }

        //setting button
        private void button1_Click(object sender, EventArgs e)
        {
            /*
            if(tbox_host_ip.Text == NetworkInfomation.DefaultIP)
            {
                MessageBox.Show("같은 호스트를 원격제어할 수 없습니다.");
                tbox_host_ip.Text = string.Empty;
                return;
            }
            */

            string host_ip = tbox_host_ip.Text;
            Rectangle rect = Remote.Single.Rect;
            Controller.Single.Start(host_ip);

            RCF.ClientSize = new Size(rect.Width - 40, rect.Height - 80);
            RCF.Show();
        }

        //accept button
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Remote.Single.RecvEventStart();
            timer1.Start();
            CS.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Text += " :" + NetworkInfomation.DefaultIP;
            CS = new Cursor();
            RCF = new RemoteClient();
            Remote.Single.RecvedRCInfo += new RecvRCInfoEventHandler(Single_RecvedRCInfo);
        }

        // 대리자 ( 크로스 쓰레드 방지 )
        delegate void RemoteDele(object sender, RecvRCInfoEventArgs e);
        void Single_RecvedRCInfo(object sender, RecvRCInfoEventArgs e)
        {
            if(this.InvokeRequired)
            {
                object[] objs = new object[2] { sender, e };
                this.Invoke(new RemoteDele(Single_RecvedRCInfo), objs);
            }
            else
            {
                tbox_controller_ip.Text = e.IPAddressStr;
                s_ip = e.IPAddressStr;
                i_port = e.Port;
                btn_accept.Enabled = true;
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Remote.Single.Stop();
            Controller.Single.Stop();
            Application.Exit();
        }

        private void tbox_controller_ip_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
