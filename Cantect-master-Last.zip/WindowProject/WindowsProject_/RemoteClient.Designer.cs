﻿
namespace WindowsProject_
{
    partial class RemoteClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.remote_pbox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.remote_pbox)).BeginInit();
            this.SuspendLayout();
            // 
            // remote_pbox
            // 
            this.remote_pbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.remote_pbox.Location = new System.Drawing.Point(0, 0);
            this.remote_pbox.Name = "remote_pbox";
            this.remote_pbox.Size = new System.Drawing.Size(909, 508);
            this.remote_pbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.remote_pbox.TabIndex = 0;
            this.remote_pbox.TabStop = false;
            // 
            // RemoteClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 508);
            this.Controls.Add(this.remote_pbox);
            this.Name = "RemoteClient";
            this.Text = "RemoteClient";
            this.Load += new System.EventHandler(this.RemoteClient_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RemoteClient_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.RemoteClient_KeyUp);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.RemoteClient_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RemoteClient_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.RemoteClient_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.remote_pbox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox remote_pbox;
    }
}