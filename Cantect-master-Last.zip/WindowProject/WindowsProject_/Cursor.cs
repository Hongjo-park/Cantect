﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowProject;

namespace WindowsProject_
{
    public partial class Cursor : Form
    {
        public Cursor()
        {
            InitializeComponent();
        }

        // 커서 사이즈 및 이벤트 받아오기
        private void Cursor_Load(object sender, EventArgs e)
        {
            Size = new Size(10, 10);
            Remote.Single.RecvedKMEvent += new RecvKMEventHandler(Sigle_RecvedKMEvent);
        }

        // 대리자
        delegate void Change_Locationdele(Point p, MsgType mt);
        void Change_Location(Point p, MsgType mt)
        {
            // 마우스 이동
            if(mt == MsgType.M_MMOVE)
            {
                Location = new Point(p.X + 3, p.Y + 3);
            }
        }

        private void Sigle_RecvedKMEvent(object sender, RecvKMEventArgs e)
        {
            // 크로스 쓰레드 방지 Invoke == true 쓰레드가 다르다.
            if(this.InvokeRequired)
            {
                object[] objs = new object[] { e.MP, e.MT };
                this.Invoke(new Change_Locationdele(Change_Location), objs);
            }
            else
            {
                Change_Location(e.MP, e.MT);
            }
        }
    }
}
