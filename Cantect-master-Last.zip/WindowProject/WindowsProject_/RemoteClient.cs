﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowProject;

namespace WindowsProject_
{
    public partial class RemoteClient : Form
    {
        bool check;
        Size C_size;
        SendEventClient Event_Client
        {
            get
            {
                return Controller.Single.SendEventClient;
            }
        }


        public RemoteClient()
        {
            InitializeComponent();
        }

        private void RemoteClient_Load(object sender, EventArgs e)
        {
            Controller.Single.RecvedImage += new RecvImageEventHandler(Single_RecvedImage);
        }

        private void Single_RecvedImage(object sender, RecvImageEventArgs e)
        {
            if(check == false)
            {
                Controller.Single.StartEventClient();
                check = true;
                C_size = e.Image.Size;
            }
            remote_pbox.Image = e.Image;
        }

        private void RemoteClient_KeyUp(object sender, KeyEventArgs e)
        {
            if(check)
            {
                Event_Client.SendKeyUp(e.KeyValue);
            }
        }

        private void RemoteClient_KeyDown(object sender, KeyEventArgs e)
        {
            if (check)
            {
                Event_Client.SendKeyDown(e.KeyValue);
            }
        }

        private void RemoteClient_MouseDown(object sender, MouseEventArgs e)
        {
            if(check)
            {
                Text = e.Location.ToString();
                Event_Client.SendMouseDown(e.Button);
            }
        }

        private void RemoteClient_MouseUp(object sender, MouseEventArgs e)
        {
            if (check)
            {
                Text = e.Location.ToString();
                Event_Client.SendMouseUP(e.Button);
            }
        }

        private void RemoteClient_MouseMove(object sender, MouseEventArgs e)
        {
            if(check)
            {
                Point p = ConvertPoint(e.X, e.Y);
                Event_Client.SendMouseMove(p.X, p.Y);
            }
        }

        /// <summary>
        /// Point의 비율 convert
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        private Point ConvertPoint(int x, int y)
        {
            // 호스트의 너비를 곱하고, pbox의 너비로 나눈다.
            int nx = C_size.Width * x / remote_pbox.Width;
            // 높이를 곱하고, pbox의 높이로 나눈다.
            int ny = C_size.Height * y / remote_pbox.Height;
            return new Point(nx, ny);
        }
    }
}
