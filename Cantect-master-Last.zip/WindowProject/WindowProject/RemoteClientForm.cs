﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowProject
{
    /// <summary>
    /// 
    /// </summary>
    public partial class RemoteClientForm : Form
    {
      
        
        /// <summary>
        /// 
        /// </summary>
        public RemoteClientForm()
        {
            InitializeComponent();
        }

        private void RemoteClientForm_Load(object sender, EventArgs e)
        {
          
        }

        private void pbox_remote_Click(object sender, EventArgs e)
        {

        }
    }
}
