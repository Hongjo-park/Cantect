﻿using System;

namespace WinFormsLibrary1
{
    public class Class1
    {
    }
}
